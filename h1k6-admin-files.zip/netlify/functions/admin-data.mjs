import { getUser } from "@netlify/identity";

export default async function handler() {
  const user = await getUser();
  if (!user) {
    return Response.json({ error: "Authentication required" }, { status: 401 });
  }
  if (!Array.isArray(user.roles) || !user.roles.includes("admin")) {
    return Response.json({ error: "Administrator role required" }, { status: 403 });
  }
  return Response.json(
    { authenticated: true, email: user.email, role: "admin" },
    { headers: { "Cache-Control": "no-store" } }
  );
}
