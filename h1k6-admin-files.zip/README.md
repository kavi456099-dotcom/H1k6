# H1K6 Admin Portal

The admin sign-in page is at `/admin/`.

## Setup before using
1. Deploy this project to the intended Netlify site.
2. In Netlify Project configuration → Identity, enable Netlify Identity.
3. Set registration to **Invite only**.
4. Invite the administrator account.
5. Assign the `admin` role in that user's `app_metadata.roles`.
6. Sign out and sign in again after changing roles so the new role is included in the session token.

The page calls a Netlify Function that independently checks the signed-in session and admin role. The browser UI alone is not the security boundary.

This starter dashboard verifies administrator access; it does not yet provide user-management or content-editing features.
